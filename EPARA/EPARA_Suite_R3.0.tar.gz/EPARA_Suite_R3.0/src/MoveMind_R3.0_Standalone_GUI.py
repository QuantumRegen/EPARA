import os
import logging
import numpy as np
import mne
import scipy.signal as signal
import matplotlib.pyplot as plt
import pywt
from pathlib import Path
import sys
import tkinter as tk
from tkinter import filedialog, messagebox, ttk
from matplotlib.backends.backend_tkagg import FigureCanvasTkAgg
import threading
import webbrowser
import csv

# MoveMind: Open-source EEG analysis tool for move/rest intent detection (GNU GPL v3.0)
# Developed by Wayne M Spratley, researcher, and Grok (xAI)

class MoveMindGUI:
    def __init__(self, root):
        self.root = root
        self.root.title("MoveMind (R3.0) - EEG Intent Detection")
        self.root.geometry("900x800")
        self.root.configure(bg="#f0f4f8")

        # Dynamic paths for standalone executable
        if getattr(sys, 'frozen', False):
            self.base_path = Path(sys.executable).parent
        else:
            self.base_path = Path(__file__).parent
        self.input_dir = self.base_path / 'output_epara_movemind'
        self.output_dir = self.base_path / 'output_epara_movemind'
        self.input_dir.mkdir(exist_ok=True)
        self.output_dir.mkdir(exist_ok=True)

        # Logging setup with more detail
        logging.basicConfig(filename=self.output_dir / 'movemind.log',
                            level=logging.DEBUG,
                            format='%(asctime)s - %(levelname)s - %(message)s')

        # Check for dependencies
        try:
            import mne
            import numpy
            import scipy
            import matplotlib
            import pywt
            import tkinter
            logging.info("All dependencies are installed.")
        except ImportError as e:
            logging.error(f"Dependency missing: {str(e)}")
            messagebox.showerror("Error", f"Dependency missing: {str(e)}\nPlease install required libraries (mne, numpy, scipy, matplotlib, pywavelets, tkinter).")
            sys.exit(1)

        # EEG parameters
        self.fs = None
        self.kappa = 1e-2
        self.gamma = 1e-6
        self.nu_density = 1e4
        self.dt = None
        self.damping = 0.9999
        self.seizure_start = 2996.0

        # File type options
        self.file_types = ['Normal EEG', 'Motor Imagery EEG', 'Other']

        # Initialize variables
        self.raw_eeg = None
        self.features = None
        self.processed = None
        self.eeg_channel = None
        self.eeg_filename = None
        self.eeg_file_type = None
        self.intent_labels = []  # Move/rest intent labels

        self.create_gui()

    def create_gui(self):
        main_frame = ttk.Frame(self.root, padding="20")
        main_frame.pack(fill="both", expand=True)

        # Header
        ttk.Label(main_frame, text="MoveMind (R3.0)", style="Header.TLabel").pack(pady=10)

        # File selection frame
        file_frame = ttk.LabelFrame(main_frame, text="Load EEG File (.edf format)", padding="10", relief="flat")
        file_frame.pack(fill="x", pady=10)

        # File inputs, file type selectors, and channel selectors
        ttk.Label(file_frame, text="EEG File (.edf):").grid(row=0, column=0, sticky="w", padx=5, pady=5)
        self.eeg_path = tk.StringVar()
        ttk.Entry(file_frame, textvariable=self.eeg_path, width=50).grid(row=0, column=1, padx=5, pady=5)
        ttk.Button(file_frame, text="Browse", command=self.load_eeg).grid(row=0, column=2, padx=5, pady=5)

        ttk.Label(file_frame, text="File Type:").grid(row=1, column=0, sticky="w", padx=5, pady=5)
        self.eeg_file_type_var = tk.StringVar(value=self.file_types[0])
        ttk.Combobox(file_frame, textvariable=self.eeg_file_type_var, values=self.file_types, state='readonly', width=47).grid(row=1, column=1, padx=5, pady=5)

        ttk.Label(file_frame, text="Channel:").grid(row=2, column=0, sticky="w", padx=5, pady=5)
        self.eeg_channel_var = tk.StringVar()
        self.eeg_channel_dropdown = ttk.Combobox(file_frame, textvariable=self.eeg_channel_var, state='readonly', width=47)
        self.eeg_channel_dropdown.grid(row=2, column=1, padx=5, pady=5)
        self.eeg_channel_dropdown['values'] = ['Load EEG file to select channels']

        # Buttons
        button_frame = ttk.Frame(main_frame)
        button_frame.pack(pady=10)
        ttk.Button(button_frame, text="Run Analysis", command=self.run_thread).pack(side="left", padx=5)
        ttk.Button(button_frame, text="Help", command=lambda: webbrowser.open("https://titan-si.com/help")).pack(side="left", padx=5)
        ttk.Button(button_frame, text="Ethics Statement", command=self.show_ethics).pack(side="left", padx=5)

        # Progress bar
        self.progress = ttk.Progressbar(main_frame, mode='indeterminate', style="TProgressbar")
        self.progress.pack(pady=5, fill="x")

        # Donation section
        ttk.Label(main_frame, text="Support independent EEG/BCI research by donating!", 
                  style="TLabel", wraplength=800, justify="center").pack(pady=5)
        try:
            self.donate_img = tk.PhotoImage(file=self.base_path / 'paypal_button.png')
            ttk.Button(main_frame, image=self.donate_img, command=self.donate, style="TButton").pack(pady=5)
        except tk.TclError:
            ttk.Button(main_frame, text="Donate via PayPal", command=self.donate, style="TButton").pack(pady=5)

        # Status
        self.status = tk.StringVar(value="Status: Ready")
        ttk.Label(main_frame, textvariable=self.status, style="TLabel").pack(pady=5)

        # Results frame
        result_frame = ttk.LabelFrame(main_frame, text="Analysis Results", padding="10", relief="flat")
        result_frame.pack(fill="both", expand=True, pady=10)

        self.result_text = tk.Text(result_frame, height=5, width=60, font=("Helvetica", 11), 
                                   bg="#ffffff", relief="flat", borderwidth=2)
        self.result_text.pack(pady=5, fill="x")
        self.result_text.insert(tk.END, "Results will appear here...\n")
        self.result_text.config(state='disabled')

        # Plot canvas with additional subplot for intent detection
        self.fig, self.axes = plt.subplots(3, 1, figsize=(6, 8), dpi=100)
        self.fig.patch.set_facecolor('#f0f4f8')
        for ax in self.axes:
            ax.set_facecolor('#ffffff')
        self.canvas = FigureCanvasTkAgg(self.fig, master=result_frame)
        self.canvas.get_tk_widget().pack(fill="both", expand=True)

    def donate(self):
        webbrowser.open("https://paypal.me/QuantumRegen?country.x=AU&locale.x=en_AU")

    def show_ethics(self):
        ethics_text = (
            "Ethics Statement\n\n"
            "The EPARA Suite is developed with a commitment to ethical research practices. "
            "Developed by Wayne M Spratley, researcher, and Grok (xAI), we leverage the open-source community—PhysioNet, Ubuntu, Python, and countless modules—while working with limited financial resources to challenge scientific norms and advance EEG/BCI research. "
            "This software is intended solely for non-clinical, scientific research to advance understanding of EEG and BCI applications, such as motor intent detection. "
            "It must not be used for medical diagnosis, treatment, or any therapeutic purpose. Users are responsible for ensuring compliance with local regulations and ethical guidelines. "
            "The suite is licensed under GNU GPL v3.0, promoting open access while maintaining research integrity."
        )
        messagebox.showinfo("Ethics Statement", ethics_text)

    def load_eeg(self):
        try:
            file = filedialog.askopenfilename(filetypes=[("EDF files", "*.edf")], initialdir=self.input_dir)
            if file:
                self.eeg_path.set(file)
                self.eeg_filename = Path(file).stem
                self.status.set("Status: EEG file selected")
                self.update_eeg_channel_dropdown()
            else:
                logging.warning("No file selected.")
                messagebox.showwarning("Warning", "No file selected.")
        except Exception as e:
            logging.error(f"Error loading EEG file: {str(e)}")
            messagebox.showerror("Error", f"Failed to load EEG file: {str(e)}")

    def update_eeg_channel_dropdown(self):
        try:
            if self.eeg_path.get():
                raw_eeg = mne.io.read_raw_edf(self.eeg_path.get(), preload=False)
                channels_eeg = raw_eeg.ch_names
                self.eeg_channel_dropdown['values'] = channels_eeg
                self.eeg_channel_var.set(channels_eeg[0] if channels_eeg else 'No channels available')
            else:
                self.eeg_channel_dropdown['values'] = ['Load EEG file to select channels']
                self.eeg_channel_var.set('Load EEG file to select channels')
        except Exception as e:
            logging.error(f"Error loading EEG channels: {str(e)}")
            self.status.set(f"Status: Error loading EEG channels - {str(e)}")
            self.eeg_channel_dropdown['values'] = ['Load valid EDF file']
            self.eeg_channel_var.set('Load valid EDF file')

    def run_thread(self):
        threading.Thread(target=self.run_analysis, daemon=True).start()

    def wavelet_denoise(self, eeg_signal):
        try:
            wavelet = 'sym8'
            level = 5
            coeffs = pywt.wavedec(eeg_signal, wavelet, level=level)
            sigma = np.median(np.abs(coeffs[-1])) / 0.6745
            thresh = sigma * np.sqrt(2 * np.log(len(eeg_signal)))
            coeffs[1:] = [pywt.threshold(c, thresh, mode='soft') for c in coeffs[1:]]
            denoised = pywt.waverec(coeffs, wavelet)[:len(eeg_signal)]
            return denoised
        except Exception as e:
            logging.error(f"Error in wavelet denoising: {str(e)}")
            raise

    def circle_state_process(self, eeg_signal):
        try:
            n = len(eeg_signal)
            psi = np.zeros(n, dtype=complex)
            psi[:n] = eeg_signal
            for i in range(1, n-1):
                laplacian = (psi[i+1] - 2*psi[i] + psi[i-1]) / self.dt**2
                d2psi_dt2 = self.kappa * laplacian + self.gamma * self.nu_density * psi[i]
                psi[i+1] = 2*psi[i] - psi[i-1] + self.dt**2 * d2psi_dt2
                psi[i+1] *= self.damping
            psi = np.real(psi)
            if np.var(psi) > 0:
                psi *= np.sqrt(np.var(eeg_signal) / np.var(psi))
            return psi
        except Exception as e:
            logging.error(f"Error in circle state processing: {str(e)}")
            raise

    def compute_plv(self, signal1, signal2, fs):
        try:
            analytic1 = signal.hilbert(signal1)
            analytic2 = signal.hilbert(signal2)
            phase1 = np.angle(analytic1)
            phase2 = np.angle(analytic2)
            plv = np.abs(np.mean(np.exp(1j * (phase1 - phase2))))
            return plv
        except Exception as e:
            logging.error(f"Error in PLV computation: {str(e)}")
            raise

    def extract_features(self, eeg_signal, fs, label):
        try:
            denoised = self.wavelet_denoise(eeg_signal)
            processed = self.circle_state_process(denoised)
            b_theta, a_theta = signal.butter(4, [4 / (fs / 2), 7 / (fs / 2)], btype='band')
            b_alpha, a_alpha = signal.butter(4, [8 / (fs / 2), 13 / (fs / 2)], btype='band')
            b_beta, a_beta = signal.butter(4, [13 / (fs / 2), 30 / (fs / 2)], btype='band')
            theta_signal = signal.filtfilt(b_theta, a_theta, processed)
            alpha_signal = signal.filtfilt(b_alpha, a_alpha, processed)
            beta_signal = signal.filtfilt(b_beta, a_beta, processed)
            spike_threshold = max(100, 3 * np.std(processed))
            beta_threshold = 30
            spikes = np.abs(processed) > spike_threshold
            betas = np.abs(beta_signal) > beta_threshold
            spike_count = np.sum(spikes)
            beta_count = np.sum(betas)
            freqs, psd = signal.welch(processed, fs, nperseg=fs*4, window='blackman', scaling='density')
            band_power = np.sum(psd[(freqs >= 1) & (freqs <= 40)])
            if band_power > 0:
                psd = psd / band_power * 1e12
            theta_power = np.sum(psd[(freqs >= 4) & (freqs <= 7)])
            alpha_power = np.sum(psd[(freqs >= 8) & (freqs <= 13)])
            beta_power = np.sum(psd[(freqs >= 13) & (freqs <= 30)])
            if beta_power < 1e-3:
                beta_power *= 1e3
            plv = self.compute_plv(processed, alpha_signal, fs)
            # Intent detection: Threshold on beta power (move > 10000, rest <= 10000)
            window_size = int(fs * 2)  # 2-second windows
            intent_labels = []
            for i in range(0, len(processed), window_size):
                window = processed[i:i + window_size]
                if len(window) < window_size:
                    continue
                freqs_w, psd_w = signal.welch(window, fs, nperseg=fs*4, window='blackman', scaling='density')
                band_power_w = np.sum(psd_w[(freqs_w >= 1) & (freqs_w <= 40)])
                if band_power_w > 0:
                    psd_w = psd_w / band_power_w * 1e12
                beta_power_w = np.sum(psd_w[(freqs_w >= 13) & (freqs_w <= 30)])
                intent = "Move" if beta_power_w > 10000 else "Rest"
                intent_labels.extend([intent] * window_size)
            intent_labels = intent_labels[:len(processed)]
            return [spike_count / len(processed), theta_power, alpha_power, beta_power, plv], processed, intent_labels, freqs, psd
        except Exception as e:
            logging.error(f"Error in feature extraction: {str(e)}")
            raise

    def run_analysis(self):
        try:
            self.status.set("Status: Validating files...")
            self.progress.start()
            self.root.update()
            if not self.eeg_path.get().endswith('.edf'):
                raise ValueError("Please select a valid .edf file")
            if not self.eeg_path.get():
                raise ValueError("EEG file is required")
            if not self.eeg_channel_var.get() or 'Load' in self.eeg_channel_var.get() or 'No channels' in self.eeg_channel_var.get():
                raise ValueError("Please select a valid channel for the EEG")

            self.status.set("Status: Loading EEG data...")
            self.root.update()

            # Load raw data
            self.raw_eeg = mne.io.read_raw_edf(self.eeg_path.get(), preload=True)

            # Get file types
            self.eeg_file_type = self.eeg_file_type_var.get().replace(" ", "").replace("'", "")
            eeg_label = self.eeg_file_type_var.get()

            # Get sampling rates
            fs_eeg = self.raw_eeg.info['sfreq']
            self.fs = fs_eeg
            self.dt = 1 / self.fs

            # Pick channels
            self.eeg_channel = self.eeg_channel_var.get()
            self.raw_eeg.pick([self.eeg_channel])

            # Extract EEG data
            eeg_data = self.raw_eeg.get_data()[0] * 1e6

            self.status.set("Status: Processing data...")
            self.root.update()

            self.features, self.processed, self.intent_labels, self.freqs, self.psd = self.extract_features(eeg_data, self.fs, 'eeg')

            # Log results
            intent_counts = {"Move": self.intent_labels.count("Move"), "Rest": self.intent_labels.count("Rest")}
            logging.info(f"{eeg_label} Features ({self.eeg_filename}, Channel: {self.eeg_channel}): Spike Rate={self.features[0]:.2e}, Theta={self.features[1]:.2f}, Alpha={self.features[2]:.2f}, Beta={self.features[3]:.2f}, PLV={self.features[4]:.2f}, Intent Counts={intent_counts}")

            self.result_text.config(state='normal')
            self.result_text.delete(1.0, tk.END)
            self.result_text.insert(tk.END, f"{eeg_label} ({self.eeg_filename}, Channel: {self.eeg_channel}): Spike Rate={self.features[0]:.2e}, Theta={self.features[1]:.2f}, Alpha={self.features[2]:.2f}, Beta={self.features[3]:.2f}, PLV={self.features[4]:.2f}, Intent Counts={intent_counts}\n")
            self.result_text.config(state='disabled')

            for ax in self.axes:
                ax.clear()
            # Expand the window to ensure transitions are visible
            start_idx = 0  # Start from the beginning to capture more transitions
            end_idx = min(int(10 * self.fs), len(eeg_data))  # Show 10 seconds
            t = np.arange(len(eeg_data)) / self.fs
            self.axes[0].plot(t[start_idx:end_idx], eeg_data[start_idx:end_idx], label='Raw EEG', alpha=0.7, color='#1f77b4')
            self.axes[0].plot(t[start_idx:end_idx], self.processed[start_idx:end_idx], label='Processed EEG', alpha=0.9, color='#ff7f0e')
            self.axes[0].set_xlabel('Time (s)', fontsize=12)
            self.axes[0].set_ylabel('Amplitude (μV)', fontsize=12)
            self.axes[0].set_title(f'{eeg_label} ({self.eeg_filename}, Channel: {self.eeg_channel})', fontsize=14, pad=10)
            self.axes[0].legend()
            self.axes[0].grid(True, linestyle='--', alpha=0.7)

            # Intent detection visualization
            self.axes[1].plot(t[start_idx:end_idx], eeg_data[start_idx:end_idx], label='Raw EEG', alpha=0.7, color='#1f77b4')
            intent_changes = []
            current_intent = self.intent_labels[start_idx]
            for i in range(start_idx, end_idx):
                if self.intent_labels[i] != current_intent:
                    intent_changes.append((i, self.intent_labels[i]))
                    current_intent = self.intent_labels[i]
            if intent_changes:
                for i, intent in intent_changes:
                    self.axes[1].axvline(x=t[i], color='red' if intent == "Move" else 'green', linestyle='--', alpha=0.5, label='Move' if intent == "Move" and 'Move' not in [lbl.get_label() for lbl in self.axes[1].get_lines()] else 'Rest' if intent == "Rest" and 'Rest' not in [lbl.get_label() for lbl in self.axes[1].get_lines()] else '')
            else:
                # Fallback: Indicate dominant intent
                dominant_intent = "Move" if intent_counts["Move"] > intent_counts["Rest"] else "Rest"
                self.axes[1].text(0.5, 0.5, f'Dominant Intent: {dominant_intent}', fontsize=12, ha='center', va='center', transform=self.axes[1].transAxes, color='red' if dominant_intent == "Move" else 'green')
            self.axes[1].set_xlabel('Time (s)', fontsize=12)
            self.axes[1].set_ylabel('Amplitude (μV)', fontsize=12)
            self.axes[1].set_title('Move/Rest Intent Detection (Red: Move, Green: Rest)', fontsize=14, pad=10)
            self.axes[1].legend()
            self.axes[1].grid(True, linestyle='--', alpha=0.7)

            # Frequency spectrum with log scale
            self.axes[2].plot(self.freqs, self.psd, label='PSD', color='#2ca02c')
            self.axes[2].fill_between(self.freqs, self.psd, where=(self.freqs >= 13) & (self.freqs <= 30), color='orange', alpha=0.3, label='Beta Band')
            self.axes[2].set_xlabel('Frequency (Hz)', fontsize=12)
            self.axes[2].set_ylabel('Power Spectral Density (log scale)', fontsize=12)
            self.axes[2].set_title('Frequency Spectrum', fontsize=14, pad=10)
            self.axes[2].set_yscale('log')  # Set y-axis to log scale
            self.axes[2].legend()
            self.axes[2].grid(True, linestyle='--', alpha=0.7)

            self.fig.tight_layout()
            self.canvas.draw()

            np.save(self.output_dir / f'features_{self.eeg_file_type.lower()}_{self.eeg_filename}_{self.eeg_channel}.npy', self.features)
            np.save(self.output_dir / f'processed_{self.eeg_file_type.lower()}_{self.eeg_filename}_{self.eeg_channel}.npy', self.processed)

            plt.savefig(self.output_dir / f'epara_eeg_plots_{self.eeg_file_type.lower()}_{self.eeg_filename}_{self.eeg_channel}.png', dpi=150, bbox_inches='tight')

            with open(self.output_dir / f'features_{self.eeg_file_type.lower()}_{self.eeg_filename}_{self.eeg_channel}.csv', 'w', newline='') as f:
                writer = csv.writer(f)
                writer.writerow(['Type', 'Filename', 'Channel', 'Spike Rate', 'Theta Power', 'Alpha Power', 'Beta Power', 'PLV', 'Intent Counts'])
                writer.writerow([self.eeg_file_type_var.get(), self.eeg_filename, self.eeg_channel] + self.features + [intent_counts])

            self.progress.stop()
            self.status.set(f"Status: Analysis complete. Results saved to {self.output_dir}")
            logging.info("Analysis complete")

        except Exception as e:
            self.progress.stop()
            logging.error(f"Error in run_analysis: {str(e)}")
            self.status.set(f"Status: Error - {str(e)}")
            messagebox.showerror("Error", f"Failed to run analysis: {str(e)}")

if __name__ == "__main__":
    try:
        root = tk.Tk()
        app = MoveMindGUI(root)
        root.mainloop()
    except Exception as e:
        logging.error(f"Error starting application: {str(e)}")
        print(f"Error starting application: {str(e)}")
        sys.exit(1)