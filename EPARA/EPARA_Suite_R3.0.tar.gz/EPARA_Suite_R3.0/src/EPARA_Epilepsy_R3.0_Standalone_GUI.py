import os
import logging
import numpy as np
import mne
import scipy.signal as signal
import matplotlib.pyplot as plt
import pywt
from pathlib import Path
import sys
import tkinter as tk
from tkinter import filedialog, messagebox, ttk
from matplotlib.backends.backend_tkagg import FigureCanvasTkAgg
import threading
import webbrowser
import csv

# EPARA_Epilepsy: Open-source EEG analysis tool for epilepsy research (GNU GPL v3.0)
# Developed by Wayne M Spratley, researcher, and Grok (xAI)

class EPARAEpilepsyGUI:
    def __init__(self, root):
        self.root = root
        self.root.title("EPARA Epilepsy (R3.0) - EEG Analysis")
        self.root.geometry("900x800")
        self.root.configure(bg="#f0f4f8")

        # Dynamic paths for standalone executable
        if getattr(sys, 'frozen', False):
            self.base_path = Path(sys.executable).parent
        else:
            self.base_path = Path(__file__).parent
        self.input_dir = self.base_path / 'output_epara_epilepsy'
        self.output_dir = self.base_path / 'output_epara_epilepsy'
        self.input_dir.mkdir(exist_ok=True)
        self.output_dir.mkdir(exist_ok=True)

        # Logging setup with more detail
        logging.basicConfig(filename=self.output_dir / 'epara_epilepsy.log',
                            level=logging.DEBUG,
                            format='%(asctime)s - %(levelname)s - %(message)s')

        # Check for dependencies
        try:
            import mne
            import numpy
            import scipy
            import matplotlib
            import pywt
            import tkinter
            logging.info("All dependencies are installed.")
        except ImportError as e:
            logging.error(f"Dependency missing: {str(e)}")
            messagebox.showerror("Error", f"Dependency missing: {str(e)}\nPlease install required libraries (mne, numpy, scipy, matplotlib, pywavelets, tkinter).")
            sys.exit(1)

        # EEG parameters
        self.fs = None
        self.kappa = 1e-2
        self.gamma = 1e-6
        self.nu_density = 1e4
        self.dt = None
        self.damping = 0.9999
        self.seizure_start = 2996.0

        # File type options
        self.file_types = ['Normal EEG', 'Epilepsy EEG', 'Motor Imagery EEG', 'Other']

        # Initialize variables
        self.raw_normal = None
        self.features_e = None
        self.features_n = None
        self.processed_e = None
        self.processed_n = None
        self.normal_channel = None
        self.normal_filename = None
        self.normal_file_type = None
        # Epilepsy simulation parameters
        self.spike_rate_increase_ep = 50.0
        self.theta_power_increase = 75.0
        self.seizure_freq = 5.0
        self.seizure_amplitude = 100.0

        self.create_gui()

    def create_gui(self):
        main_frame = ttk.Frame(self.root, padding="20")
        main_frame.pack(fill="both", expand=True)

        # Header
        ttk.Label(main_frame, text="EPARA Epilepsy (R3.0)", style="Header.TLabel").pack(pady=10)

        # File selection frame
        file_frame = ttk.LabelFrame(main_frame, text="Load EEG File (.edf format)", padding="10", relief="flat")
        file_frame.pack(fill="x", pady=10)

        # File inputs, file type selectors, and channel selectors
        ttk.Label(file_frame, text="Normal EEG (.edf):").grid(row=0, column=0, sticky="w", padx=5, pady=5)
        self.n_path = tk.StringVar()
        ttk.Entry(file_frame, textvariable=self.n_path, width=50).grid(row=0, column=1, padx=5, pady=5)
        ttk.Button(file_frame, text="Browse", command=self.load_normal).grid(row=0, column=2, padx=5, pady=5)

        ttk.Label(file_frame, text="Normal File Type:").grid(row=1, column=0, sticky="w", padx=5, pady=5)
        self.normal_file_type_var = tk.StringVar(value=self.file_types[0])
        ttk.Combobox(file_frame, textvariable=self.normal_file_type_var, values=self.file_types, state='readonly', width=47).grid(row=1, column=1, padx=5, pady=5)

        ttk.Label(file_frame, text="Normal Channel:").grid(row=2, column=0, sticky="w", padx=5, pady=5)
        self.normal_channel_var = tk.StringVar()
        self.normal_channel_dropdown = ttk.Combobox(file_frame, textvariable=self.normal_channel_var, state='readonly', width=47)
        self.normal_channel_dropdown.grid(row=2, column=1, padx=5, pady=5)
        self.normal_channel_dropdown['values'] = ['Load normal EDF file to select channels']

        # Epilepsy simulation parameters
        ttk.Label(file_frame, text="Epilepsy Spike Rate Increase (%, 0-100):").grid(row=3, column=0, sticky="w", padx=5, pady=5)
        self.spike_rate_increase_ep_var = tk.StringVar(value=str(self.spike_rate_increase_ep))
        ttk.Entry(file_frame, textvariable=self.spike_rate_increase_ep_var, width=50).grid(row=3, column=1, padx=5, pady=5)

        ttk.Label(file_frame, text="Epilepsy Theta Power Increase (%, 0-100):").grid(row=4, column=0, sticky="w", padx=5, pady=5)
        self.theta_power_increase_var = tk.StringVar(value=str(self.theta_power_increase))
        ttk.Entry(file_frame, textvariable=self.theta_power_increase_var, width=50).grid(row=4, column=1, padx=5, pady=5)

        ttk.Label(file_frame, text="Epilepsy Seizure Frequency (Hz, 3-8):").grid(row=5, column=0, sticky="w", padx=5, pady=5)
        self.seizure_freq_var = tk.StringVar(value=str(self.seizure_freq))
        ttk.Entry(file_frame, textvariable=self.seizure_freq_var, width=50).grid(row=5, column=1, padx=5, pady=5)

        ttk.Label(file_frame, text="Epilepsy Seizure Amplitude (μV, 0-200):").grid(row=6, column=0, sticky="w", padx=5, pady=5)
        self.seizure_amplitude_var = tk.StringVar(value=str(self.seizure_amplitude))
        ttk.Entry(file_frame, textvariable=self.seizure_amplitude_var, width=50).grid(row=6, column=1, padx=5, pady=5)

        # Buttons
        button_frame = ttk.Frame(main_frame)
        button_frame.pack(pady=10)
        ttk.Button(button_frame, text="Run Analysis", command=self.run_thread).pack(side="left", padx=5)
        ttk.Button(button_frame, text="Help", command=lambda: webbrowser.open("https://titan-si.com/help")).pack(side="left", padx=5)
        ttk.Button(button_frame, text="Ethics Statement", command=self.show_ethics).pack(side="left", padx=5)

        # Progress bar
        self.progress = ttk.Progressbar(main_frame, mode='indeterminate', style="TProgressbar")
        self.progress.pack(pady=5, fill="x")

        # Donation section
        ttk.Label(main_frame, text="Support independent EEG/BCI research by donating!", 
                  style="TLabel", wraplength=800, justify="center").pack(pady=5)
        try:
            self.donate_img = tk.PhotoImage(file=self.base_path / 'paypal_button.png')
            ttk.Button(main_frame, image=self.donate_img, command=self.donate, style="TButton").pack(pady=5)
        except tk.TclError:
            ttk.Button(main_frame, text="Donate via PayPal", command=self.donate, style="TButton").pack(pady=5)

        # Status
        self.status = tk.StringVar(value="Status: Ready")
        ttk.Label(main_frame, textvariable=self.status, style="TLabel").pack(pady=5)

        # Results frame
        result_frame = ttk.LabelFrame(main_frame, text="Analysis Results", padding="10", relief="flat")
        result_frame.pack(fill="both", expand=True, pady=10)

        self.result_text = tk.Text(result_frame, height=5, width=60, font=("Helvetica", 11), 
                                   bg="#ffffff", relief="flat", borderwidth=2)
        self.result_text.pack(pady=5, fill="x")
        self.result_text.insert(tk.END, "Results will appear here...\n")
        self.result_text.config(state='disabled')

        # Plot canvas with additional subplot for epilepsy metrics
        self.fig, self.axes = plt.subplots(3, 1, figsize=(6, 8), dpi=100)
        self.fig.patch.set_facecolor('#f0f4f8')
        for ax in self.axes:
            ax.set_facecolor('#ffffff')
        self.canvas = FigureCanvasTkAgg(self.fig, master=result_frame)
        self.canvas.get_tk_widget().pack(fill="both", expand=True)

    def donate(self):
        webbrowser.open("https://paypal.me/QuantumRegen?country.x=AU&locale.x=en_AU")

    def show_ethics(self):
        ethics_text = (
            "Ethics Statement\n\n"
            "The EPARA Suite is developed with a commitment to ethical research practices. "
            "Developed by Wayne M Spratley, researcher, and Grok (xAI), we leverage the open-source community—PhysioNet, Ubuntu, Python, and countless modules—while working with limited financial resources to challenge scientific norms and advance EEG/BCI research. "
            "This software is intended solely for non-clinical, scientific research to advance understanding of EEG and BCI applications, such as epilepsy analysis. "
            "It must not be used for medical diagnosis, treatment, or any therapeutic purpose. Users are responsible for ensuring compliance with local regulations and ethical guidelines. "
            "The suite is licensed under GNU GPL v3.0, promoting open access while maintaining research integrity."
        )
        messagebox.showinfo("Ethics Statement", ethics_text)

    def load_normal(self):
        try:
            file = filedialog.askopenfilename(filetypes=[("EDF files", "*.edf")], initialdir=self.input_dir)
            if file:
                self.n_path.set(file)
                self.normal_filename = Path(file).stem
                self.status.set("Status: Normal EEG file selected")
                self.update_normal_channel_dropdown()
            else:
                logging.warning("No file selected.")
                messagebox.showwarning("Warning", "No file selected.")
        except Exception as e:
            logging.error(f"Error loading normal EEG file: {str(e)}")
            messagebox.showerror("Error", f"Failed to load normal EEG file: {str(e)}")

    def update_normal_channel_dropdown(self):
        try:
            if self.n_path.get():
                raw_n = mne.io.read_raw_edf(self.n_path.get(), preload=False)
                channels_n = raw_n.ch_names
                self.normal_channel_dropdown['values'] = channels_n
                self.normal_channel_var.set(channels_n[0] if channels_n else 'No channels available')
            else:
                self.normal_channel_dropdown['values'] = ['Load normal EDF file to select channels']
                self.normal_channel_var.set('Load normal EDF file to select channels')
        except Exception as e:
            logging.error(f"Error loading normal channels: {str(e)}")
            self.status.set(f"Status: Error loading normal channels - {str(e)}")
            self.normal_channel_dropdown['values'] = ['Load valid EDF file']
            self.normal_channel_var.set('Load valid EDF file')

    def run_thread(self):
        threading.Thread(target=self.run_analysis, daemon=True).start()

    def wavelet_denoise(self, eeg_signal):
        try:
            wavelet = 'sym8'
            level = 5
            coeffs = pywt.wavedec(eeg_signal, wavelet, level=level)
            sigma = np.median(np.abs(coeffs[-1])) / 0.6745
            thresh = sigma * np.sqrt(2 * np.log(len(eeg_signal)))
            coeffs[1:] = [pywt.threshold(c, thresh, mode='soft') for c in coeffs[1:]]
            denoised = pywt.waverec(coeffs, wavelet)[:len(eeg_signal)]
            return denoised
        except Exception as e:
            logging.error(f"Error in wavelet denoising: {str(e)}")
            raise

    def circle_state_process(self, eeg_signal):
        try:
            n = len(eeg_signal)
            psi = np.zeros(n, dtype=complex)
            psi[:n] = eeg_signal
            for i in range(1, n-1):
                laplacian = (psi[i+1] - 2*psi[i] + psi[i-1]) / self.dt**2
                d2psi_dt2 = self.kappa * laplacian + self.gamma * self.nu_density * psi[i]
                psi[i+1] = 2*psi[i] - psi[i-1] + self.dt**2 * d2psi_dt2
                psi[i+1] *= self.damping
            psi = np.real(psi)
            if np.var(psi) > 0:
                psi *= np.sqrt(np.var(eeg_signal) / np.var(psi))
            return psi
        except Exception as e:
            logging.error(f"Error in circle state processing: {str(e)}")
            raise

    def compute_plv(self, signal1, signal2, fs):
        try:
            analytic1 = signal.hilbert(signal1)
            analytic2 = signal.hilbert(signal2)
            phase1 = np.angle(analytic1)
            phase2 = np.angle(analytic2)
            plv = np.abs(np.mean(np.exp(1j * (phase1 - phase2))))
            return plv
        except Exception as e:
            logging.error(f"Error in PLV computation: {str(e)}")
            raise

    def extract_features(self, eeg_signal, fs, label):
        try:
            denoised = self.wavelet_denoise(eeg_signal)
            processed = self.circle_state_process(denoised)
            b_theta, a_theta = signal.butter(4, [4 / (fs / 2), 7 / (fs / 2)], btype='band')
            b_alpha, a_alpha = signal.butter(4, [8 / (fs / 2), 13 / (fs / 2)], btype='band')
            b_beta, a_beta = signal.butter(4, [13 / (fs / 2), 30 / (fs / 2)], btype='band')
            theta_signal = signal.filtfilt(b_theta, a_theta, processed)
            alpha_signal = signal.filtfilt(b_alpha, a_alpha, processed)
            beta_signal = signal.filtfilt(b_beta, a_beta, processed)
            spike_threshold = max(100, 3 * np.std(processed))
            beta_threshold = 30
            spikes = np.abs(processed) > spike_threshold
            betas = np.abs(beta_signal) > beta_threshold
            spike_count = np.sum(spikes)
            beta_count = np.sum(betas)
            freqs, psd = signal.welch(processed, fs, nperseg=fs*4, window='blackman', scaling='density')
            band_power = np.sum(psd[(freqs >= 1) & (freqs <= 40)])
            if band_power > 0:
                psd = psd / band_power * 1e12  # Final adjusted scaling factor
            theta_power = np.sum(psd[(freqs >= 4) & (freqs <= 7)])
            alpha_power = np.sum(psd[(freqs >= 8) & (freqs <= 13)])
            beta_power = np.sum(psd[(freqs >= 13) & (freqs <= 30)])
            if beta_power < 1e-3:
                beta_power *= 1e3
            spike_frequency = spike_count / (len(processed) / fs)
            seizure_events = np.where(spikes)[0]
            seizure_duration = 0
            if len(seizure_events) > 0:
                event_starts = [seizure_events[0]]
                event_ends = []
                for i in range(1, len(seizure_events)):
                    if seizure_events[i] - seizure_events[i-1] > fs:
                        event_ends.append(seizure_events[i-1])
                        event_starts.append(seizure_events[i])
                event_ends.append(seizure_events[-1])
                seizure_duration = sum((end - start) / fs for start, end in zip(event_starts, event_ends))
            plv = self.compute_plv(processed, alpha_signal, fs)
            return [spike_count / len(processed), theta_power, alpha_power, beta_power, spike_frequency, seizure_duration, plv], processed, spikes, freqs, psd
        except Exception as e:
            logging.error(f"Error in feature extraction: {str(e)}")
            raise

    def run_analysis(self):
        try:
            self.status.set("Status: Validating files...")
            self.progress.start()
            self.root.update()
            if not self.n_path.get().endswith('.edf'):
                raise ValueError("Please select a valid .edf file")
            if not self.n_path.get():
                raise ValueError("Normal EEG file is required")
            if not self.normal_channel_var.get() or 'Load' in self.normal_channel_var.get() or 'No channels' in self.normal_channel_var.get():
                raise ValueError("Please select a valid channel for the normal EEG")

            # Validate epilepsy simulation parameters
            try:
                self.spike_rate_increase_ep = float(self.spike_rate_increase_ep_var.get())
                if not (0 <= self.spike_rate_increase_ep <= 100):
                    raise ValueError("Epilepsy spike rate increase must be between 0 and 100%")
            except ValueError as e:
                raise ValueError(f"Invalid epilepsy spike rate increase: {str(e)}")

            try:
                self.theta_power_increase = float(self.theta_power_increase_var.get())
                if not (0 <= self.theta_power_increase <= 100):
                    raise ValueError("Theta power increase must be between 0 and 100%")
            except ValueError as e:
                raise ValueError(f"Invalid theta power increase: {str(e)}")

            try:
                self.seizure_freq = float(self.seizure_freq_var.get())
                if not (3 <= self.seizure_freq <= 8):
                    raise ValueError("Seizure frequency must be between 3 and 8 Hz")
            except ValueError as e:
                raise ValueError(f"Invalid seizure frequency: {str(e)}")

            try:
                self.seizure_amplitude = float(self.seizure_amplitude_var.get())
                if not (0 <= self.seizure_amplitude <= 200):
                    raise ValueError("Seizure amplitude must be between 0 and 200 μV")
            except ValueError as e:
                raise ValueError(f"Invalid seizure amplitude: {str(e)}")

            self.status.set("Status: Loading EEG data...")
            self.root.update()

            # Load raw data
            self.raw_normal = mne.io.read_raw_edf(self.n_path.get(), preload=True)

            # Get file types
            self.normal_file_type = self.normal_file_type_var.get().replace(" ", "").replace("'", "")
            seizure_label = "Epilepsy EEG"
            normal_label = self.normal_file_type_var.get()

            # Get sampling rates
            fs_n = self.raw_normal.info['sfreq']
            self.fs = fs_n
            self.dt = 1 / self.fs

            # Pick channels
            self.normal_channel = self.normal_channel_var.get()
            self.raw_normal.pick([self.normal_channel])

            # Extract normal EEG data
            eeg_normal = self.raw_normal.get_data()[0] * 1e6

            # Apply epilepsy simulation to normal EEG
            t = np.arange(len(eeg_normal)) / self.fs
            seizure_signal = self.seizure_amplitude * np.sin(2 * np.pi * self.seizure_freq * t)
            eeg_seizure_simulated = eeg_normal + seizure_signal

            # Simulate epilepsy by increasing spike rate
            _, processed_normal, _, _, _ = self.extract_features(eeg_normal, self.fs, 'normal')
            spikes_normal = np.abs(processed_normal) > max(100, 3 * np.std(processed_normal))
            spike_count_normal = np.sum(spikes_normal)
            target_spike_count_ep = int(spike_count_normal * (1 + self.spike_rate_increase_ep / 100))
            additional_spikes_ep = target_spike_count_ep - spike_count_normal
            if additional_spikes_ep > 0:
                non_spike_indices = np.where(~spikes_normal)[0]
                if len(non_spike_indices) > 0:
                    spike_indices = np.random.choice(non_spike_indices, size=min(additional_spikes_ep, len(non_spike_indices)), replace=False)
                    eeg_seizure_simulated[spike_indices] += np.random.normal(150, 50, size=len(spike_indices))

            # Simulate epilepsy by increasing theta power
            freqs, psd = signal.welch(eeg_seizure_simulated, self.fs, nperseg=self.fs*8, window='blackman', scaling='density')
            band_power = np.sum(psd[(freqs >= 1) & (freqs <= 40)])
            if band_power > 0:
                psd = psd / band_power * 1e9
            theta_power = np.sum(psd[(freqs >= 4) & (freqs <= 7)])
            target_theta_power = theta_power * (1 + self.theta_power_increase / 100)
            theta_increase = target_theta_power - theta_power
            if theta_increase > 0:
                theta_signal_amplified = (self.seizure_amplitude + np.sqrt(theta_increase)) * np.sin(2 * np.pi * self.seizure_freq * t)
                eeg_seizure_simulated += theta_signal_amplified

            self.status.set("Status: Processing data...")
            self.root.update()

            self.features_e, self.processed_e, self.spikes_e, self.freqs_e, self.psd_e = self.extract_features(eeg_seizure_simulated, self.fs, 'epilepsy')
            self.features_n, self.processed_n, self.spikes_n, self.freqs_n, self.psd_n = self.extract_features(eeg_normal, self.fs, 'normal')

            logging.info(f"Simulated {seizure_label} Features ({self.normal_filename}_simulated_epilepsy, Channel: {self.normal_channel}, Spike Rate Increase: {self.spike_rate_increase_ep}%, Theta Power Increase: {self.theta_power_increase}%, Seizure Freq: {self.seizure_freq} Hz, Seizure Amp: {self.seizure_amplitude} μV): Spike Rate={self.features_e[0]:.2e}, Theta={self.features_e[1]:.2f}, Alpha={self.features_e[2]:.2f}, Beta={self.features_e[3]:.2f}, Spike Frequency={self.features_e[4]:.2f}, Seizure Duration={self.features_e[5]:.2f}s, PLV={self.features_e[6]:.2f}")
            logging.info(f"{normal_label} Features ({self.normal_filename}, Channel: {self.normal_channel}): Spike Rate={self.features_n[0]:.2e}, Theta={self.features_n[1]:.2f}, Alpha={self.features_n[2]:.2f}, Beta={self.features_n[3]:.2f}, Spike Frequency={self.features_n[4]:.2f}, Seizure Duration={self.features_n[5]:.2f}s, PLV={self.features_n[6]:.2f}")

            self.result_text.config(state='normal')
            self.result_text.delete(1.0, tk.END)
            self.result_text.insert(tk.END, f"Simulated {seizure_label} ({self.normal_filename}_simulated_epilepsy, Channel: {self.normal_channel}, Spike Rate Increase: {self.spike_rate_increase_ep}%, Theta Power Increase: {self.theta_power_increase}%, Seizure Freq: {self.seizure_freq} Hz, Seizure Amp: {self.seizure_amplitude} μV): Spike Rate={self.features_e[0]:.2e}, Theta={self.features_e[1]:.2f}, Alpha={self.features_e[2]:.2f}, Beta={self.features_e[3]:.2f}, Spike Frequency={self.features_e[4]:.2f}, Seizure Duration={self.features_e[5]:.2f}s, PLV={self.features_e[6]:.2f}\n")
            self.result_text.insert(tk.END, f"{normal_label} ({self.normal_filename}, Channel: {self.normal_channel}): Spike Rate={self.features_n[0]:.2e}, Theta={self.features_n[1]:.2f}, Alpha={self.features_n[2]:.2f}, Beta={self.features_n[3]:.2f}, Spike Frequency={self.features_n[4]:.2f}, Seizure Duration={self.features_n[5]:.2f}s, PLV={self.features_n[6]:.2f}\n")
            self.result_text.config(state='disabled')

            for ax in self.axes:
                ax.clear()
            start_idx = int(self.seizure_start * self.fs) if self.seizure_start * self.fs < len(eeg_normal) else 0
            end_idx = min(start_idx + int(2 * self.fs), len(eeg_normal))
            self.axes[0].plot(t[start_idx:end_idx], eeg_normal[start_idx:end_idx], label='Raw EEG', alpha=0.7, color='#1f77b4')
            self.axes[0].plot(t[start_idx:end_idx], self.processed_n[start_idx:end_idx], label='Processed EEG', alpha=0.9, color='#ff7f0e')
            self.axes[0].set_xlabel('Time (s)', fontsize=12)
            self.axes[0].set_ylabel('Amplitude (μV)', fontsize=12)
            self.axes[0].set_title(f'{normal_label} ({self.normal_filename}, Channel: {self.normal_channel})', fontsize=14, pad=10)
            self.axes[0].legend()
            self.axes[0].grid(True, linestyle='--', alpha=0.7)

            self.axes[1].plot(t[start_idx:end_idx], eeg_seizure_simulated[start_idx:end_idx], label='Raw EEG', alpha=0.7, color='#1f77b4')
            self.axes[1].plot(t[start_idx:end_idx], self.processed_e[start_idx:end_idx], label='Processed EEG', alpha=0.9, color='#ff7f0e')
            self.axes[1].set_xlabel('Time (s)', fontsize=12)
            self.axes[1].set_ylabel('Amplitude (μV)', fontsize=12)
            self.axes[1].set_title(f'Simulated {seizure_label} ({self.normal_filename}_simulated_epilepsy, Channel: {self.normal_channel})', fontsize=14, pad=10)
            self.axes[1].legend()
            self.axes[1].grid(True, linestyle='--', alpha=0.7)

            # Epilepsy-specific visualization: Spike events and seizure frequency spectrum
            self.axes[2].plot(t[start_idx:end_idx], eeg_seizure_simulated[start_idx:end_idx], label='Raw EEG', alpha=0.7, color='#1f77b4')
            spike_times = t[start_idx:end_idx][self.spikes_e[start_idx:end_idx]]
            spike_amplitudes = eeg_seizure_simulated[start_idx:end_idx][self.spikes_e[start_idx:end_idx]]
            self.axes[2].scatter(spike_times, spike_amplitudes, color='red', label='Spikes', marker='x')
            self.axes[2].set_xlabel('Time (s)', fontsize=12)
            self.axes[2].set_ylabel('Amplitude (μV)', fontsize=12)
            self.axes[2].set_title('Spike Events', fontsize=14, pad=10)
            self.axes[2].legend()
            self.axes[2].grid(True, linestyle='--', alpha=0.7)

            self.fig.tight_layout()
            self.canvas.draw()

            np.save(self.output_dir / f'features_simulated_epilepsy_{self.normal_filename}_{self.normal_channel}.npy', self.features_e)
            np.save(self.output_dir / f'features_{self.normal_file_type.lower()}_{self.normal_filename}_{self.normal_channel}.npy', self.features_n)
            np.save(self.output_dir / f'processed_simulated_epilepsy_{self.normal_filename}_{self.normal_channel}.npy', self.processed_e)
            np.save(self.output_dir / f'processed_{self.normal_file_type.lower()}_{self.normal_filename}_{self.normal_channel}.npy', self.processed_n)

            plt.savefig(self.output_dir / f'epara_eeg_plots_simulated_epilepsy_{self.normal_filename}_{self.normal_channel}.png', dpi=150, bbox_inches='tight')

            with open(self.output_dir / f'features_simulated_epilepsy_{self.normal_filename}_{self.normal_channel}.csv', 'w', newline='') as f:
                writer = csv.writer(f)
                writer.writerow(['Type', 'Filename', 'Channel', 'Spike Rate', 'Theta Power', 'Alpha Power', 'Beta Power', 'Spike Frequency', 'Seizure Duration (s)', 'PLV'])
                writer.writerow([f'Simulated {seizure_label}', f'{self.normal_filename}_simulated_epilepsy', self.normal_channel] + self.features_e)
                writer.writerow([self.normal_file_type_var.get(), self.normal_filename, self.normal_channel] + self.features_n)

            self.progress.stop()
            self.status.set(f"Status: Analysis complete. Results saved to {self.output_dir}")
            logging.info("Analysis complete")

        except Exception as e:
            self.progress.stop()
            logging.error(f"Error in run_analysis: {str(e)}")
            self.status.set(f"Status: Error - {str(e)}")
            messagebox.showerror("Error", f"Failed to run analysis: {str(e)}")

if __name__ == "__main__":
    try:
        root = tk.Tk()
        app = EPARAEpilepsyGUI(root)
        root.mainloop()
    except Exception as e:
        logging.error(f"Error starting application: {str(e)}")
        print(f"Error starting application: {str(e)}")
        sys.exit(1)